filename = 'programming.txt'

with open(filename, 'w') as file_object:
	file_object.write("I love programming.\n")
	file_object.write("I love create new things.\n")


# wirte()函数不会在文本行末自动加换行符\n，需要手动添加，才能给各行换行。
