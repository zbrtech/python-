filename = 'pi_digits.txt'

'''
with open(filename) as file_object:    
	contents = file_object.read()
	print(contents.rstrip())
'''

with open(filename) as file_object:
	for line in file_object:  #没有通过read()方法，一行行历遍。read()的意义是包括换行符一起复制？？？
		#print(line)
		print(line.rstrip())  #去掉末尾的换行符


# open()方法返回的不是文件内容，是这个文件的对象。
#要获得内容需要用方法读取：read()读取整个文件内容并作为字符串返回；read（）每次读取文件中的一行内容并返回;readlines（）也是读取整个文件内容，但是不返回字符串，返回一个列表，列表的每个元素都是文件一行的内容（字符串+末尾换行符）
