1.相对路径，会在本python程序所在的文件夹中找到text_files文件夹，并进入里面去找filename.txt。

with open('text_files/filename.txt') as file_object:
	... ...



2.绝对路径，一般绝对路径比较长，所以先存入一个变量，再作为参数传入open（）中

file_path= '/home/ehmatthes/other_files/text_files/filename.txt'
with open(file_path) as file_object:
	... ...
