filename = 'programming.txt'

with open(filename, 'a') as file_object:
	file_object.write("I love swimming.\n")
	file_object.write("I love danceing.\n")


# 'a'实参表示在文件末尾添加内容，不会清除掉原本的内容
