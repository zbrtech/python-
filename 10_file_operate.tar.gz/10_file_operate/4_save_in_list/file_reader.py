filename = 'pi_digits.txt'

with open(filename) as file_object:
	lines = file_object.readlines()


for line in lines:
	print(line.rstrip())


# 打开的文件对象，只能在with所在代码块内使用。要在外部使用，可以将其存入一个列表中，而readlines()方法自动把每行存为一个元素，最终汇集成一个列表返回，刚刚好！
