filename = 'programming.txt'

with open(filename, 'w') as file_object:
	file_object.write("I love programming.")


# 实参‘w’表示输入模式，‘r’表示读取模式。，‘a’表示附加模式，‘r+’表示读取、写入模式。缺省时，默认为读取模式。
# 如果要写入的文件不存在，open（）函数会自动创建它
# ‘w’输入模式，如果文件已经存在，会先清空原本的文件！！！！！！！
# python只能将字符串写入文本文件中，数值无法写入。可以用str()将其转化为字符串格式，再存储。
