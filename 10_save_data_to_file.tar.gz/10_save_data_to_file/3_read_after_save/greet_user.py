import json

filename = 'username_file.json'  #如果这个文件不存在，open（）会自动创建

with open(filename) as f_obj:   #默认是读取模式，就不用传open()的第二个参数了
	username = json.load(f_obj)
	print('welcome back, ' + username)

# json.load(要读取的文件open（）后的对象)，返回文件内存储的数据，并且格式也一样
# greet欢迎的意思
