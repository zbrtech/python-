import json

username = input('what is your name ?  ')

filename = 'username_file.json'  #如果这个文件不存在，open（）会自动创建

with open(filename, 'w') as f_obj:
	json.dump(username, f_obj)
	print("we will remember you when you come back, " + username + " !")
