import json

filename = 'username_file.json'  #如果这个文件不存在，open（）会自动创建

try:
	with open(filename) as f_obj:   
		username = json.load(f_obj)
except FileNotFoundError:
	username = input('what is your name ?  ')
	with open(filename, 'w') as f_obj:
		json.dump(username, f_obj)
		print("we will remember you when you come back, " + username + " !")
else:
	print('welcome back, ' + username)   # 这一句直接放在try的代码块里面应该也可吧




