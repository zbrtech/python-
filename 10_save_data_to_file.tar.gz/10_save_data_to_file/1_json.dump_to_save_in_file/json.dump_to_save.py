import json

numbers = [2, 3, 5, 7, 11, 13]
# numbers = 'zbr'   #这边有引号的字符串，print的时候，就不会打印出引号了

filename = 'numbers.json'  #如果这个文件不存在，open（）会自动创建

with open(filename, 'w') as f_obj:
	json.dump(numbers, f_obj)

# json.dump(要储存的数据此处为一个列表list， 要用来存储数据的文件打开后的对象)
# dump（）用来把数据存储到文件里面
# dump()的第一个参数，可以是list、字符串，还有哪些呢？
# 存储的数据会按照原本的格式存储，list还是list，字符串还是字符串
