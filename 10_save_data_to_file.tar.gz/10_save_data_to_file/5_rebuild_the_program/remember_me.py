import json

def get_stored_username():
	filename = 'username_file.json'  
	try:
		with open(filename) as f_obj:   
			username = json.load(f_obj)
	except FileNotFoundError:
		return None   #不做任何处理，与pass有什么区别？None在判断中为0
	else:
		return username    

def get_new_username():
	username = input('what is your name ? ')
	filename = 'username_file.json'  
	with open(filename, 'w') as f_obj:
		json.dump(username, f_obj)
		print("we will remember you when you come back, " + username + " !")
	return username

def greet_user():
	username = get_stored_username()
	if username:   # 非空为真
		print('welcome back, ' + username)
	else:
		username = get_new_username()

greet_user()
