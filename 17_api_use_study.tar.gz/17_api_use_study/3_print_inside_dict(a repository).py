import requests

url = 'https://api.github.com/search/repositories?q=language:python&sort=stars'
r = requests.get(url)
print("Status code:", r.status_code)

response_dict = r.json()
print("Total repositories:",response_dict['total_count'])


repo_dicts = response_dict['items']
print("Repositories returned:", len(repo_dicts))

repo_dict = repo_dicts[0]
# 排行第一的项目
#---------------------------------#

print("\nSelected information about first repository:")
print('name:',repo_dict['name'])
print('owner:',repo_dict['owner']['login']) # owner也是一个字典，里面有登录名、登录验证码等？
print('stars:',repo_dict['stargazers_count'])
print('repository:',repo_dict['html_url'])
print('created:',repo_dict['created_at'])
print('updated:',repo_dict['updated_at'])
print('description:',repo_dict['description'])
