import requests

url = 'https://api.github.com/search/repositories?q=language:python&sort=stars'
r = requests.get(url)
print("Status code:", r.status_code)

response_dict = r.json() # 接收了整个json文件，本体是一个字典

print("Total repositories:",response_dict['total_count'])  
# 打印这个大字典的'total_count'键的值


repo_dicts = response_dict['items']
# 取得存于'items'键的列表，这个列表里面存了多个字典，所以名字里有dicts字段
print("Repositories returned:", len(repo_dicts))
# 打印返回列表的长度，API实际并没有全部项目都返回来，毕竟有20几万个项目

repo_dict = repo_dicts[0]   # 列表的第0项，即为排行第一的项目所在的字典
print("\nkeys:", len(repo_dict))   # 打印这个小字典的长度，看它内部多少个键值对，即有多少信息
for key in sorted(repo_dict.keys()): # 历遍这个小字典，打印出该项目小字典含有多少个键

	print(key)
