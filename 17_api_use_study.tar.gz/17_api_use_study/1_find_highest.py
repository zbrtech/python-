import requests

url = 'https://api.github.com/search/repositories?q=language:python&sort=stars'
r = requests.get(url)
print("Status code:", r.status_code)   # 状态码用来告知是否成功

response_dict = r.json()     # 这个json文件内存储的是一个字典，本体可以在raw data里面看到
	# 这个字典里面，其中一个键items的值是一个list，这个list里面存类多个字典

print(response_dict.keys())
	# 打印的是最外曾字典的所有键项


