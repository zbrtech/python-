import requests
import pygal
from pygal.style import LightColorizedStyle as LCS, LightenStyle as LS

url = 'https://api.github.com/search/repositories?q=language:python&sort=stars'
# ?导入一个参数q,而q的内容是等号后面的信息
# 通过api接口，自己根据需求这样设计url地址，功能很强大
r = requests.get(url)
print("Status code:", r.status_code)

response_dict = r.json()
print("Total repositories:",response_dict['total_count'])

names,stars = [], []

repo_dicts = response_dict['items']

for repo_dict in repo_dicts:
	names.append(repo_dict['name'])  # 历遍来装载，以列表的形式，形成数据
	stars.append(repo_dict['stargazers_count'])


my_style = LS('#333366',base_style=LCS)
chart = pygal.Bar(style=my_style, x_label_rotation=45,show_legend=False)

chart.title = 'most-starred python projects on github'
chart.x_labels = names  # x轴数据
chart.add('',stars)     # y轴数据

chart.render_to_file('stars_of_repos.svg')  #渲染至文件

# ctrl + L 可以查看文件完整路径
# svg的图片用浏览器渲染，好慢啊
