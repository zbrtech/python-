def count_words(filename):
	try:
		with open(filename) as f_obj:
			contents = f_obj.read()
	except FileNotFoundError:
		msg = "sorry, the file" + filename + "dose not exits."
		print(msg)
	else:
		words = contents.split()
		num_words = len(words)
		print('the file ' + filename + ' has about ' + str(num_words) + ' words')

filenames = ['Quncas Borba.txt', 'The Call of the Wild.txt', 'zbr.txt']

for filename in filenames:
	count_words(filename)
