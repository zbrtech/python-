filename = 'Quncas Borba.txt'

try:
	with open(filename) as f_obj:
		contents = f_obj.read()
except FileNotFoundError:
	msg = "sorry, the file" + filename + "dose not exits."
	print(msg)
else:
	words = contents.split()
	num_words = len(words)
	print('the file ' + filename + ' has about ' + str(num_words) + ' words')


# split()将长字符串以空格为分隔符，拆分成一个个单词。并且生成返回一个列表，每个单词都散列表里面的一个元素。
