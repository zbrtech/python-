def count_words(filename):
	try:
		with open(filename) as f_obj:
			contents = f_obj.read()
	except FileNotFoundError:
		pass
		# pass代表什么都不做，沉默。也是占位符，提醒这边可以做一些其他的事情
	else:
		words = contents.split()
		num_words = len(words)
		print('the file ' + filename + ' has about ' + str(num_words) + ' words')

filenames = ['Quncas Borba.txt', 'The Call of the Wild.txt', 'zbr.txt']

for filename in filenames:
	count_words(filename)
