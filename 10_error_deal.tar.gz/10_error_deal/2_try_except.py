try:
	print(5/0)
except ZeroDivisionError:   #这个错误类型是系统定好的，出现除以0的错误时，就自动生成返回这个错误类型对象
			    #用except来捕捉这个错误类型，并且做出处理。整个程序就能继续运行下去，不会中断、报错。
	print('you can not divide by zero !')
