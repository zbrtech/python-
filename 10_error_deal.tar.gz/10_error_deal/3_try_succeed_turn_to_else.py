print('give me two numbers, and I will divide them.\n enter "q" to quit.')

while True:
	first_number = input('\nFirst number:')
	if first_number == 'q':
		break

	second_number = input('Second number:')
	if first_number == 'q':   # 这边为什么失效
		break


	try:
		answer = int(first_number) / int(second_number)
	except ZeroDivisionError:     # 注意冒号的位置
		print('you can not divide by zero !')
	else:
		print(answer)

# try里面的代码执行错误，就用except提供的错误类型去检测，类型也对的上就执行它的代码块；如果try里面的代码块执行正确无误，就执行else带的代码块。
