import csv
from matplotlib import pyplot as plt
from datetime import datetime

filename = 'sitka_weather_2014.csv'
with open(filename) as f:
	reader = csv.reader(f)
	header_row = next(reader)
	
	dates, highs = [], []
	for row in reader:                #get column 1 
		current_date = datetime.strptime(row[0], "%d/%m/%y %H:%M")
		dates.append(current_date)
		high = float(row[1])
		highs.append(row[1])      #get second value of every column

	print(highs)

fig = plt.figure(dpi=128, figsize=(10,6))

plt.plot(dates, highs, c='red',linewidth=0.5)   # x, y
plt.title('daily high temperatures, 2014', fontsize=24)
plt.xlabel('',fontsize=16)
fig.autofmt_xdate                 #auto adjust the x label
plt.ylabel('Temperature', fontsize=16)
plt.tick_params(axis='both', which='major', labelsize=16)

plt.show()
