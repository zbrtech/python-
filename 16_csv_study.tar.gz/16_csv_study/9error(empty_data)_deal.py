#deal with some empty data
...

dates, highs, lows = [], [], []
for row in reader:
	try:
		current_date = datetime.strptim(row[0], "%d/%m/%y %H:%M")
		high = float(row[1])
		low = float(row[2])
	except ValueError:
		print(current_date, 'missing data')
	else:
		dates.append(current_date)
		highs.append(high)
		lows.append(low)

..
	
