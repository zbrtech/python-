#file 4

import pygal  #add this modul
from die import Die

mdie = Die()  #try =Die(8) or =Die(6)

results = []

for roll_num in range(1000):
    result = mdie.roll()
    results.append(result)

frequencies = []

for value in range(1, mdie.num_sides+1):
    frequency = results.count(value)
    frequencies.append(frequency)

hist = pygal.Bar()   #one class!!!must be

hist.title = 'Result of rolling one D6 1000times'
hist.x_labels = ['1','2','3','4','5','6']
hist.x_title = 'Result'
hist.y_title = 'frequency of Result'

hist.add('D6',frequencies)
hist.render_to_file('hist_show.svg')
# hist.render()
