#file 2

from die import Die

mdie = Die()  #try =Die(8) or =Die(6)

results = []

for roll_num in range(100):
    result = mdie.roll()
    results.append(result)

print(results)
