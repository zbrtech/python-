#file 1

from random import randint

class Die():    #one class to simulate se zi

    def __init__(self, num_sides=6):
        self.num_sides = num_sides

    def roll(self):    #return a number between 1 to self.num_sides
        return randint(1, self.num_sides)    #randint is different with choice
