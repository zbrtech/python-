#file 3

from die import Die

mdie = Die()  #try =Die(8) or =Die(6)

results = []

for roll_num in range(1000):
    result = mdie.roll()
    results.append(result)

frequencies = []

for value in range(1, mdie.num_sides+1):
    frequency = results.count(value)
    frequencies.append(frequency)

print(frequencies)
