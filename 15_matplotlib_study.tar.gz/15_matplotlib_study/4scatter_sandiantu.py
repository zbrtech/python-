import matplotlib.pyplot as plt

plt.scatter(2,4,s=400)   #add x,y position, s means size
plt.show()
