import matplotlib.pyplot as plt

squares = [1,4,9,16,25]

plt.plot(squares)

plt.show()
