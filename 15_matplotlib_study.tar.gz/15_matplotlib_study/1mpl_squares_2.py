import matplotlib.pyplot as plt

squares = [1,4,9,16,25,36,49]

plt.plot(squares)

plt.show()
