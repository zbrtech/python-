import sys

import pygame

def check_events():   #响应按键、鼠标的事件  

	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			sys.exit()               #选择关闭，就退出




