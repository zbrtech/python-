import sys

import pygame

from settings import Settings

def run_game():
    #init game, and create a screen object
    pygame.init()
    ai_settings = Settings()
    screen = pygame.display.set_mode((ai_settings.screen_width, ai_settings.screen_height))
    pygame.display.set_caption("Alien_Invasion")



    #start the main circle of game
    while True:
        #watch keyboard event and mouseclick event
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()

        screen.fill(ai_settings.bg_color)  #everytime fill color for secreen 

        #show the latest drawed display
        pygame.display.flip()

run_game()
